/*
 * $ Copyright Cypress Semiconductor $
 */

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include <nx_secure_tls_api.h>
#include <stdbool.h>
/******************************************************
 *                      Macros
 ******************************************************/

/******************************************************
 *                    Typedefs
 ******************************************************/

/* IMPLEMENTATION NOTE: Core supplicant implementation should not access any of the structure members defined in this file */

typedef NX_SECURE_TLS_SESSION cy_tls_session_t;
typedef NX_SECURE_X509_CERT   cy_x509_crt_t;
typedef NX_SECURE_TLS_SESSION cy_tls_workspace_t;

typedef struct
{
    NX_SECURE_X509_CERT     certificate;
    uint8_t                 *certificate_der;
    uint8_t                 *private_key_der;
    uint8_t                 is_client_auth;
} cy_tls_identity_t;

typedef struct
{
    void                    *usr_data;
    char                    *peer_cn;
    cy_tls_session_t        *session;
    cy_tls_workspace_t      context;
    cy_tls_identity_t       *identity;
    cy_x509_crt_t           *root_ca_certificates;
    uint8_t                 *root_ca_cert_der;
    int8_t                  *tls_metadata;
    uint8_t                 *tls_packet_buffer;
    uint8_t                 *certificate_buffer;
    int32_t                 resume;
    bool                    tls_handshake_successful;
    bool                    tls_v13;
    uint8_t                 expected_pkt_count;
} cy_tls_context_t;

#ifdef __cplusplus
} /*extern "C" */
#endif
