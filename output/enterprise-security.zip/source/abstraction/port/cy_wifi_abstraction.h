/*
 * $ Copyright Cypress Semiconductor $
 */

/** @file
 *  Prototypes of functions for controlling the Wi-Fi system
 */

#include "cy_supplicant_core_constants.h"
#include "cy_enterprise_security.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
    WIFI_NOT_CONNECTED,
    WIFI_CONNECTED
} wifi_connection_status_t;


cy_rslt_t connect_ent( const char *ssid, uint8_t ssid_length, const char *password, uint8_t password_length, cy_enterprise_security_auth_t auth_type );
cy_rslt_t disconnect_ent( void );
void wifi_on_ent( void );
wifi_connection_status_t is_wifi_connected( void );

#ifdef __cplusplus
} /*extern "C" */
#endif
