/*
 * $ Copyright Cypress Semiconductor $
 */

/** @file
 *  Implements functions for registering and unregistering for eapol packets with
 *  the underlying WHD layer.
 */
#include "cy_enterprise_security_log.h"
#include "cy_enterprise_security_error.h"
#include "cy_supplicant_host.h"
#include "cy_wifimwcore_eapol.h"

cy_rslt_t cy_ent_sec_register_eapol_packet_handler(cy_ent_sec_eapol_packet_handler_t eapol_packet_handler)
{
    if(cy_wifimwcore_eapol_register_receive_handler((cy_wifimwcore_eapol_packet_handler_t)eapol_packet_handler) != CY_RSLT_SUCCESS)
    {
        cy_enterprise_security_log_msg(CYLF_MIDDLEWARE, CY_LOG_ERR, "Failed to register eapol receive handler.\n");
        return CY_RSLT_ENTERPRISE_SECURITY_ERROR;
    }

    cy_enterprise_security_log_msg(CYLF_MIDDLEWARE, CY_LOG_DEBUG, "Successfully registered eapol packet handler.\r\n");
    return CY_RSLT_SUCCESS;
}

void cy_ent_sec_unregister_eapol_packet_handler(void)
{
    cy_wifimwcore_eapol_register_receive_handler(NULL);
    cy_enterprise_security_log_msg(CYLF_MIDDLEWARE, CY_LOG_DEBUG, "Successfully unregistered eapol packet handler.\r\n");
}
