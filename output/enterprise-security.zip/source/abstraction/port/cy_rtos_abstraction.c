/*
 * $ Copyright Cypress Semiconductor $
 */

/** @file
 *  Implements functions for calling RTOS APIs in AnyCloud
 *
 *  This file provides specific RTOS APIs
 *
 */

#include <stdlib.h>

#include "cy_rtos_abstraction.h"

void* cy_rtos_malloc( uint32_t size )
{
    return malloc( size );
}

void* cy_rtos_calloc( uint32_t num, uint32_t size )
{
    return calloc( num, size );
}

void cy_rtos_free( void* p )
{
    free( p );
}

