/*
 * $ Copyright Cypress Semiconductor $
 */

/** @file
 *  Prototypes of functions for controlling enterprise security network
 */

#pragma once

#include "WhdSTAInterface.h"
#ifdef __cplusplus
extern "C" {
#endif
#include "cy_enterprise_security.h"

#ifdef __cplusplus
}
#endif


/**
 * \addtogroup enterprise_security_class
 * \{
 */

/**
 * EnterpriseSecurity class
 *
 * @brief
 * Defines Enterprise Security class with methods to join/leave an enterprise network.
 */
class EnterpriseSecurity : public WhdSTAInterface
{
public:
    /**
     * EnterpriseSecurity constructor
     *
     * @param[in]  ent_parameters : Pointer to \ref cy_enterprise_security_parameters_t structure,
     *                              initialized by the caller with the details required for establishing connection with the enterprise network.
     */
    EnterpriseSecurity(cy_enterprise_security_parameters_t *ent_parameters);

    /**
     * EnterpriseSecurity destructor
     */
    ~EnterpriseSecurity();

    /**
     * Joins an enterprise security network (802.1x Access point)
     *
     * @return cy_rslt_t  : CY_RSLT_SUCCESS - on success, an error code otherwise.
     *                      Error codes returned by this function are: \n
     *                     \ref CY_RSLT_ENTERPRISE_SECURITY_BADARG \n
     *                     \ref CY_RSLT_ENTERPRISE_SECURITY_ALREADY_CONNECTED \n
     *                     \ref CY_RSLT_ENTERPRISE_SECURITY_NOMEM \n
     *                     \ref CY_RSLT_ENTERPRISE_SECURITY_JOIN_ERROR \n
     *                     \ref CY_RSLT_ENTERPRISE_SECURITY_SUPPLICANT_ERROR
     */
    cy_rslt_t join( void );

    /**
     * Leaves an Enterprise security network (802.1x Access point)
     *
     * @return cy_rslt_t  : CY_RSLT_SUCCESS - on success, an error code otherwise.
     *                      Error codes returned by this function are: \n
     *                     \ref CY_RSLT_ENTERPRISE_SECURITY_BADARG \n
     *                     \ref CY_RSLT_ENTERPRISE_SECURITY_NOT_CONNECTED \n
     *                     \ref CY_RSLT_ENTERPRISE_SECURITY_LEAVE_ERROR \n
     *                     \ref CY_RSLT_ENTERPRISE_SECURITY_SUPPLICANT_ERROR
     */
    cy_rslt_t leave( void );

private:
    cy_enterprise_security_t handle; /**< Pointer to store the Enterprise Security instance handle for internal use. */
};

/** \} enterprise_security_class */
