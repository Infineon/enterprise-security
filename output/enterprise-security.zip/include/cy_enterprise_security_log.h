/*
 * $ Copyright Cypress Semiconductor $
*/

#ifndef INCLUDED_CY_ENTERPRISE_SECURITY_LOG_H_
#define INCLUDED_CY_ENTERPRISE_SECURITY_LOG_H_

#include "cy_log.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @addtogroup enterprise_security_defines
 *  @{
 */

/**
 * ENABLE_ENTERPRISE_SECURITY_LOGS
 *
 * When defined, enables debug logs in the Enterprise Security library.
 *
 * The application must enable this flag and call `cy_log_init()` before calling these library APIs.
 */

#ifdef ENABLE_ENTERPRISE_SECURITY_LOGS
#define cy_enterprise_security_log_msg                   cy_log_msg
#else
#define cy_enterprise_security_log_msg(a,b,c,...)
#endif

/**
 * @}
 */

#ifdef __cplusplus
} /*extern "C" */
#endif

#endif /* INCLUDED_CY_ENTERPRISE_SECURITY_LOG_H_ */
